#!/usr/bin/env python3
"""Local GNSS dashboard backed by the bundled QZ1 NMEA parser."""

import argparse
import json
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from gnss_core import GNSSMonitor, NMEAStream

try:
    import serial
    from serial.tools import list_ports
except ImportError:
    serial = None
    list_ports = None


ROOT = Path(__file__).resolve().parent
LOCK = threading.RLock()
MONITOR = GNSSMonitor()
STREAM = NMEAStream()
SESSION = {
    "connected": False,
    "port": None,
    "baud": None,
    "error": None,
    "last_update": None,
}
TRAIL = []
ACTIVE_SERIAL = None
STOP_EVENT = None
WORKER = None


def get_ports():
    if list_ports is None:
        return []
    return [
        {"device": item.device, "description": item.description or item.device}
        for item in list_ports.comports()
    ]


def serial_reader(port, baud, device, stop_event, monitor, stream):
    global ACTIVE_SERIAL
    try:
        while not stop_event.is_set():
            raw = device.read(256)
            if not raw:
                continue
            sentences = stream.feed(raw)
            with LOCK:
                if ACTIVE_SERIAL is not device:
                    continue
                SESSION["last_update"] = time.time()
                for sentence in sentences:
                    monitor.process_sentence(sentence)
                    data = monitor.data
                    lat = data.get("latitude")
                    lon = data.get("longitude")
                    if data.get("fix") and lat is not None and lon is not None:
                        point = {"lat": lat, "lon": lon, "time": data.get("utc_time")}
                        if not TRAIL or TRAIL[-1]["lat"] != lat or TRAIL[-1]["lon"] != lon:
                            TRAIL.append(point)
                            del TRAIL[:-500]
    except Exception as exc:
        if not stop_event.is_set():
            with LOCK:
                SESSION["error"] = str(exc)
    finally:
        try:
            device.close()
        except Exception:
            pass
        with LOCK:
            if ACTIVE_SERIAL is device:
                ACTIVE_SERIAL = None
                SESSION["connected"] = False
                SESSION["port"] = None
                SESSION["baud"] = None


def connect(port, baud):
    global ACTIVE_SERIAL, STOP_EVENT, WORKER, MONITOR, STREAM
    if serial is None:
        raise RuntimeError("pyserial がありません。setup.bat を実行してください。")
    if not isinstance(port, str) or not port.strip():
        raise ValueError("シリアルポートを選択してください。")
    try:
        baud = int(baud)
    except (TypeError, ValueError):
        raise ValueError("通信速度を数値で入力してください。")
    if baud < 300 or baud > 4000000:
        raise ValueError("通信速度は 300〜4,000,000 の範囲で指定してください。")

    with LOCK:
        if SESSION["connected"]:
            raise RuntimeError("すでに接続しています。")

    try:
        device = serial.Serial(
            port=port,
            baudrate=baud,
            bytesize=serial.EIGHTBITS,
            parity=serial.PARITY_NONE,
            stopbits=serial.STOPBITS_ONE,
            timeout=0.2,
        )
    except Exception as exc:
        raise RuntimeError("ポートを開けませんでした: " + str(exc))

    monitor = GNSSMonitor()
    stream = NMEAStream()
    stop_event = threading.Event()
    worker = threading.Thread(
        target=serial_reader,
        args=(port, baud, device, stop_event, monitor, stream),
        daemon=True,
    )
    with LOCK:
        MONITOR = monitor
        STREAM = stream
        TRAIL.clear()
        SESSION.update({
            "connected": True,
            "port": port,
            "baud": baud,
            "error": None,
            "last_update": None,
        })
        ACTIVE_SERIAL = device
        STOP_EVENT = stop_event
        WORKER = worker
    worker.start()


def disconnect():
    global ACTIVE_SERIAL, STOP_EVENT
    with LOCK:
        device = ACTIVE_SERIAL
        stop_event = STOP_EVENT
        ACTIVE_SERIAL = None
        STOP_EVENT = None
        SESSION.update({"connected": False, "port": None, "baud": None})
        if stop_event is not None:
            stop_event.set()
    if device is not None:
        try:
            device.close()
        except Exception:
            pass


def state_snapshot():
    with LOCK:
        return {
            **SESSION,
            "data": dict(MONITOR.data),
            "stats": dict(MONITOR.stats),
            "noise_bytes": STREAM.noise_bytes,
            "trail": list(TRAIL),
        }


class Handler(BaseHTTPRequestHandler):
    def log_message(self, _format, *_args):
        return

    def send_json(self, body, status=200):
        encoded = json.dumps(body, ensure_ascii=False, allow_nan=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(encoded)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(encoded)

    def do_GET(self):
        if self.path == "/api/state":
            self.send_json(state_snapshot())
            return
        if self.path == "/api/ports":
            self.send_json({"available": serial is not None, "ports": get_ports()})
            return
        static_files = {
            "/": ("index.html", "text/html; charset=utf-8"),
            "/index.html": ("index.html", "text/html; charset=utf-8"),
            "/style.css": ("style.css", "text/css; charset=utf-8"),
            "/app.js": ("app.js", "text/javascript; charset=utf-8"),
        }
        item = static_files.get(self.path)
        if item is None:
            self.send_error(404)
            return
        filename, content_type = item
        content = (ROOT / filename).read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(content)))
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()
        self.wfile.write(content)

    def do_POST(self):
        if self.path not in ("/api/connect", "/api/disconnect"):
            self.send_error(404)
            return
        try:
            if self.path == "/api/disconnect":
                disconnect()
                self.send_json({"ok": True})
                return
            length = int(self.headers.get("Content-Length", "0"))
            if length > 4096:
                self.send_json({"error": "リクエストが大きすぎます。"}, 413)
                return
            payload = json.loads(self.rfile.read(length) or b"{}")
            connect(payload.get("port"), payload.get("baud", 115200))
            self.send_json({"ok": True})
        except (ValueError, RuntimeError, json.JSONDecodeError) as exc:
            self.send_json({"error": str(exc)}, 400)


def main():
    parser = argparse.ArgumentParser(description="Local GNSS web dashboard")
    parser.add_argument("--port", type=int, default=8765, help="web server port")
    args = parser.parse_args()
    server = ThreadingHTTPServer(("127.0.0.1", args.port), Handler)
    print("GNSS Web Dashboard: http://127.0.0.1:" + str(args.port))
    print("終了するにはこのウィンドウで Ctrl+C を押してください。")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        disconnect()
        server.server_close()


if __name__ == "__main__":
    main()
