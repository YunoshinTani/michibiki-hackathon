var map = null;
var marker = null;
var trackLine = null;
var lastPosition = null;
var mapReady = false;
var dom = {};

function byId(id) { return document.getElementById(id); }
function text(id, value) { byId(id).textContent = value; }
function showMessage(message, isError) {
  var target = byId('message');
  target.textContent = message;
  target.classList.toggle('error', Boolean(isError));
}
function numberText(value, digits) {
  if (value === null || value === undefined || value === '') return '--';
  var parsed = Number(value);
  return Number.isFinite(parsed) ? parsed.toFixed(digits) : '--';
}
function initMap() {
  if (!window.L) {
    text('map-message', '地図ライブラリを読み込めません。インターネット接続を確認してください。');
    return;
  }
  map = L.map('map', { zoomControl: true, scrollWheelZoom: true }).setView([35, 138], 3);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
  }).addTo(map);
  trackLine = L.polyline([], { color: '#43d6b0', weight: 3, opacity: 0.82 }).addTo(map);
  mapReady = true;
  setTimeout(function () { map.invalidateSize(); }, 150);
}
function setPosition(data, trail) {
  var lat = Number(data.latitude);
  var lon = Number(data.longitude);
  if (!Number.isFinite(lat) || !Number.isFinite(lon) || Math.abs(lat) > 90 || Math.abs(lon) > 180) return;
  lastPosition = [lat, lon];
  text('latitude-value', lat.toFixed(7) + '°');
  text('longitude-value', lon.toFixed(7) + '°');
  byId('center-map').disabled = false;
  if (!mapReady) return;
  var confirmed = Boolean(data.fix);
  var icon = L.divIcon({ className: '', html: '<div class="position-marker' + (confirmed ? '' : ' no-fix') + '"></div>', iconSize: [18, 18], iconAnchor: [9, 9] });
  if (!marker) marker = L.marker(lastPosition, { icon: icon }).addTo(map);
  else marker.setLatLng(lastPosition).setIcon(icon);
  marker.bindPopup((confirmed ? '測位中' : 'Fixなし / 報告位置') + '<br>' + lat.toFixed(7) + ', ' + lon.toFixed(7));
  var points = Array.isArray(trail) ? trail.map(function (p) { return [Number(p.lat), Number(p.lon)]; }) : [];
  trackLine.setLatLngs(points);
  if (points.length === 0) trackLine.setLatLngs([lastPosition]);
  if (!map._gnssCentered) {
    map.setView(lastPosition, 15);
    map._gnssCentered = true;
  }
}
function update(snapshot) {
  var data = snapshot.data || {};
  var stats = snapshot.stats || {};
  var connected = Boolean(snapshot.connected);
  var status = byId('connection-status');
  status.classList.toggle('connected', connected);
  status.classList.toggle('error', Boolean(snapshot.error));
  text('connection-label', connected ? '接続中 · ' + snapshot.port : (snapshot.error ? '接続エラー' : '未接続'));
  byId('connect-button').disabled = connected;
  byId('disconnect-button').disabled = !connected;

  var fixed = Boolean(data.fix);
  var fixCard = document.querySelector('.fix-card');
  fixCard.classList.toggle('fixed', fixed);
  text('fix-value', fixed ? 'FIX' : (data.latitude === null ? '--' : 'NO FIX'));
  text('fix-detail', fixed ? '位置を測位しています' : '有効な測位を待っています');
  text('satellites-value', data.satellites === null || data.satellites === undefined ? '--' : String(data.satellites));
  text('altitude-value', numberText(data.altitude, 1));
  text('speed-value', numberText(data.speed_kmh, 1));
  text('course-value', data.course === null || data.course === undefined ? '方位 --' : '方位 ' + numberText(data.course, 1) + '°');
  text('utc-value', data.utc_time || '--:--:--');
  text('hdop-value', numberText(data.hdop, 2));
  var hdop = Number(data.hdop);
  var meter = byId('hdop-meter');
  meter.style.width = Number.isFinite(hdop) ? Math.max(3, Math.min(100, 100 / Math.max(hdop, 0.2))) + '%' : '0%';
  meter.style.background = Number.isFinite(hdop) && hdop <= 2 ? 'var(--teal)' : 'var(--amber)';
  text('quality-badge', data.gnsa_fix_type === null || data.gnsa_fix_type === undefined ? '--' : ({ 1: 'NO FIX', 2: '2D', 3: '3D' }[data.gnsa_fix_type] || 'UNKNOWN'));
  text('quality-value', data.fix_quality === null || data.fix_quality === undefined ? '--' : String(data.fix_quality));
  text('mode-value', data.fix_mode || '--');
  text('type-value', data.gnsa_fix_type === null || data.gnsa_fix_type === undefined ? '--' : String(data.gnsa_fix_type));
  text('date-value', data.utc_date || '--');
  text('received-value', String(stats.received || 0));
  text('valid-value', String(stats.valid || 0));
  text('checksum-value', String(stats.bad_checksum || 0));
  text('malformed-value', String(stats.malformed || 0));
  text('unknown-value', String(stats.unknown || 0));
  text('noise-value', String(snapshot.noise_bytes || 0));
  text('battery-value', data.battery === null || data.battery === undefined ? '--' : numberText(data.battery, 2) + ' V*');
  text('mag-value', Array.isArray(data.mag) && data.mag.length ? data.mag.join(', ') : '--');
  text('updated-value', snapshot.last_update ? new Date(snapshot.last_update * 1000).toLocaleTimeString('ja-JP') : '--');

  if (data.latitude !== null && data.longitude !== null) {
    setPosition(data, snapshot.trail);
    byId('map-message').style.display = 'none';
  } else if (!connected) {
    byId('map-message').style.display = 'flex';
  }
  if (snapshot.error) showMessage(snapshot.error, true);
  else if (connected) showMessage(snapshot.last_update ? 'NMEAデータを受信しています。' : 'ポートに接続しました。NMEAデータを待っています。', false);
  else if (serialUnavailable) showMessage('pyserial が未導入です。setup.bat を実行してください。', true);
}

var serialUnavailable = false;
async function refreshPorts() {
  var select = byId('port-select');
  var previous = select.value;
  try {
    var response = await fetch('/api/ports', { cache: 'no-store' });
    var result = await response.json();
    serialUnavailable = !result.available;
    select.innerHTML = '<option value="">ポートを選択</option>';
    (result.ports || []).forEach(function (item) {
      var option = document.createElement('option');
      option.value = item.device;
      option.textContent = item.device + ' — ' + item.description;
      select.appendChild(option);
    });
    if (previous) select.value = previous;
    if (serialUnavailable) showMessage('pyserial が未導入です。setup.bat を実行してください。', true);
    else if (!result.ports.length) showMessage('シリアルポートが見つかりません。受信機を接続してください。', false);
    else showMessage('検出: ' + result.ports.map(function (item) { return item.device; }).join(', ') + '。ポートを選択してください。', false);
  } catch (error) {
    showMessage('ローカルサーバーに接続できません。start.bat を起動してください。', true);
  }
}
async function pollState() {
  try {
    var response = await fetch('/api/state', { cache: 'no-store' });
    update(await response.json());
  } catch (error) {
    showMessage('ローカルサーバーに接続できません。start.bat を起動してください。', true);
  }
}
async function connectDevice() {
  var port = byId('port-select').value;
  var baud = Number(byId('baud-input').value);
  if (!port) { showMessage('シリアルポートを選択してください。', true); return; }
  showMessage('接続しています…', false);
  try {
    var response = await fetch('/api/connect', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ port: port, baud: baud }) });
    var result = await response.json();
    if (!response.ok) throw new Error(result.error || '接続できませんでした。');
    await pollState();
  } catch (error) { showMessage(error.message, true); }
}
async function disconnectDevice() {
  try {
    await fetch('/api/disconnect', { method: 'POST' });
    await pollState();
    showMessage('切断しました。', false);
  } catch (error) { showMessage(error.message, true); }
}

document.addEventListener('DOMContentLoaded', function () {
  dom = { connect: byId('connect-button'), disconnect: byId('disconnect-button') };
  initMap();
  dom.connect.addEventListener('click', connectDevice);
  dom.disconnect.addEventListener('click', disconnectDevice);
  byId('refresh-ports').addEventListener('click', refreshPorts);
  byId('center-map').addEventListener('click', function () { if (map && lastPosition) map.setView(lastPosition, Math.max(map.getZoom(), 15)); });
  refreshPorts();
  pollState();
  window.setInterval(function () { if (byId('connect-button').disabled === false) refreshPorts(); }, 5000);
  window.setInterval(pollState, 1000);
});
